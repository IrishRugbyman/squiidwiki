CREATE VIEW actions AS
SELECT 'shootings' AS table_name, id, shooter_id, victim_id, date FROM shootings
UNION ALL
SELECT 'murders' AS table_name, id, shooter_id, victim_id, date FROM murders
UNION ALL
SELECT 'assists' AS table_name, id, shooter_id, victim_id, date FROM assists;

