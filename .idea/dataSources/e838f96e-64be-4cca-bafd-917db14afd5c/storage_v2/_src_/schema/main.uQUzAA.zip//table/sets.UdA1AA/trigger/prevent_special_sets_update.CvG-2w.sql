CREATE TRIGGER prevent_special_sets_update
            BEFORE UPDATE OF id, name ON sets
            WHEN OLD.id IN (SELECT value FROM config)
            BEGIN
                SELECT RAISE(ABORT, 'Cannot modify system sets');
            END;

