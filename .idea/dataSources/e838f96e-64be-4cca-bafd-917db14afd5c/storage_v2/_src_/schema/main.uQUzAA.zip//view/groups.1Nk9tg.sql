CREATE VIEW groups AS
SELECT 'sets' AS table_name, id, name, description, type FROM sets
UNION ALL
SELECT 'alliances' AS table_name, id, name, description, NULL AS type FROM alliances
UNION ALL
SELECT 'members' AS table_name, id, name, NULL AS description, status AS type FROM members;

