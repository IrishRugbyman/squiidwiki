CREATE TRIGGER prevent_special_sets_delete
            BEFORE DELETE ON sets
            WHEN OLD.id IN (SELECT value FROM config)
            BEGIN
                SELECT RAISE(ABORT, 'Cannot delete system sets');
            END;

